export class AppConstants {

    public static baseUrl = 'https://api.openweathermap.org';
    public static api = '5a4b2d457ecbef9eb2a71e480b947604';
    public static numberOfDay=5;
}