export interface Weather{
    date:Date
    description: string,
    icon: string,
    iconImage:string,
    currentTemp:number,
    maxTemp: number,
    minTemp:number
   }