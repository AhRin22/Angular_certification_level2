export  interface Location{
    zip:string,
    name: string,
    lat:number,
    lon: number,
    country: string
 
   }